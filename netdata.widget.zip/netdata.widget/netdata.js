command: "",

refreshFrequency: 10000000,

render: function (output) {
  return "<iframe width=\"500\" height=\"800\" src=\"netdata.widget/netdata.html\" frameborder=\"0\" allowfullscreen></iframe>";
},

style: "        \n\
  top: 0px      \n\
  right: 0px    \n\
  z-index: 1000 \n\
  opacity: 1    \n\
"
